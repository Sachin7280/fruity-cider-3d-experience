import React from 'react';
import { Flavor, FloatingItem } from './types';
import { AppleSVG, PearSVG, PassionFruitSVG } from './components/Fruits';

export const FLAVORS: Flavor[] = [
  {
    id: 'apple',
    title: 'Apple',
    color: '#fc7f7f',
    canGradient: 'linear-gradient(to right, #ff3b3b, #ff5c5c, #d62828, #ff3b3b)',
    subtitle: 'Sweet Apple',
    icon: <AppleSVG />,
    price: 350,
  },
  {
    id: 'pear',
    title: 'Pear',
    color: '#a8e063',
    canGradient: 'linear-gradient(to right, #8cc63f, #aee25c, #6b9c2a, #8cc63f)',
    subtitle: 'Green Pear',
    icon: <PearSVG />,
    price: 400,
  },
  {
    id: 'exotic',
    title: 'Exotic',
    color: '#a890fe',
    canGradient: 'linear-gradient(to right, #8e68ff, #b59bff, #6b44d6, #8e68ff)',
    subtitle: 'Exotic Mix',
    icon: <PassionFruitSVG fill="#4B0082" inner="#FFA500" />,
    price: 450,
  }
];

export const FLOATING_ITEMS: Record<string, FloatingItem[]> = {
  apple: [
    { id: 1, content: <AppleSVG />, x: '18vw', y: '15vh', size: '100px', rotate: 15, delay: 0 },
    { id: 2, content: <AppleSVG />, x: '75vw', y: '20vh', size: '120px', rotate: -65, delay: 0.1 },
    { id: 3, content: <AppleSVG />, x: '12vw', y: '70vh', size: '150px', rotate: -40, delay: 0.2 },
    { id: 4, content: <AppleSVG />, x: '80vw', y: '65vh', size: '110px', rotate: 45, delay: 0.15 },
  ],
  pear: [
    { id: 1, content: <PearSVG />, x: '15vw', y: '25vh', size: '110px', rotate: 40, delay: 0 },
    { id: 2, content: <PearSVG />, x: '72vw', y: '15vh', size: '120px', rotate: -85, delay: 0.1 },
    { id: 3, content: <PearSVG />, x: '10vw', y: '60vh', size: '140px', rotate: -30, delay: 0.2 },
    { id: 4, content: <PearSVG />, x: '85vw', y: '70vh', size: '110px', rotate: 65, delay: 0.15 },
  ],
  exotic: [
    { id: 1, content: <PassionFruitSVG fill="#4B0082" inner="#FFA500" />, x: '12vw', y: '20vh', size: '100px', rotate: 10, delay: 0 },
    { id: 2, content: <PassionFruitSVG fill="#4B0082" inner="#FFA500" />, x: '82vw', y: '16vh', size: '120px', rotate: -50, delay: 0.1 },
    { id: 3, content: <PassionFruitSVG fill="#4B0082" inner="#FFA500" />, x: '8vw', y: '65vh', size: '140px', rotate: -45, delay: 0.2 },
    { id: 4, content: <PassionFruitSVG fill="#4B0082" inner="#FFA500" />, x: '78vw', y: '70vh', size: '110px', rotate: 40, delay: 0.15 },
  ]
};
