import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Flavor } from '../types';

export interface CartItem {
  flavor: Flavor;
  quantity: number;
}

interface AppContextType {
  cart: CartItem[];
  addToCart: (flavor: Flavor) => void;
  removeFromCart: (flavorId: string) => void;
  updateQuantity: (flavorId: string, quantity: number) => void;
  isCartOpen: boolean;
  setIsCartOpen: (isOpen: boolean) => void;
  isRegisterOpen: boolean;
  setIsRegisterOpen: (isOpen: boolean) => void;
  user: { name: string; email: string } | null;
  setUser: (user: { name: string; email: string } | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isRegisterOpen, setIsRegisterOpen] = useState(false);
  const [user, setUser] = useState<{name: string, email: string} | null>(null);

  const addToCart = (flavor: Flavor) => {
    setCart(prev => {
      const existing = prev.find(item => item.flavor.id === flavor.id);
      if (existing) {
        return prev.map(item => item.flavor.id === flavor.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { flavor, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (flavorId: string) => {
    setCart(prev => prev.filter(item => item.flavor.id !== flavorId));
  };

  const updateQuantity = (flavorId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(flavorId);
      return;
    }
    setCart(prev => prev.map(item => item.flavor.id === flavorId ? { ...item, quantity } : item));
  };

  return (
    <AppContext.Provider value={{
      cart, addToCart, removeFromCart, updateQuantity,
      isCartOpen, setIsCartOpen,
      isRegisterOpen, setIsRegisterOpen,
      user, setUser
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useAppContext must be used within an AppProvider');
  return context;
};
