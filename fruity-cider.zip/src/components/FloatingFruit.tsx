import React from 'react';
import { motion } from 'motion/react';
import { FloatingItem } from '../types';

export const FloatingFruit: React.FC<{ item: FloatingItem; direction: number }> = ({ item, direction }) => {
  return (
    <motion.div
      initial={{ 
        opacity: 0, 
        scale: 0.5, 
        x: direction > 0 ? 150 : -150 
      }}
      animate={{ opacity: 1, scale: 1, x: 0 }}
      exit={{ opacity: 0, transition: { duration: 0.4 } }}
      transition={{ 
        delay: item.delay, 
        duration: 0.8, 
        ease: [0.34, 1.56, 0.64, 1] 
      }}
      className="absolute z-20 pointer-events-none"
      style={{ left: item.x, top: item.y, fontSize: item.size }}
    >
      <motion.div
         animate={{ 
            y: [0, -25, 0], 
            rotate: [item.rotate, item.rotate + 15, item.rotate] 
         }}
         transition={{ 
            repeat: Infinity, 
            duration: 3 + item.id * 0.5, 
            ease: "easeInOut" 
         }}
      >
        {item.content}
      </motion.div>
    </motion.div>
  );
};
