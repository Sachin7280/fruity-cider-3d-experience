import React, { useRef } from 'react';
import { motion, useScroll, useTransform, useSpring, useMotionValue } from 'motion/react';
import { MessageCircle, ShoppingBag } from 'lucide-react';
import { Can } from './Can';
import { FLAVORS } from '../data';
import { Flavor } from '../types';
import { useAppContext } from '../context/AppContext';

const Section1 = () => {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });

  const rotateY = useTransform(scrollYProgress, [0, 1], [-60, 60]);
  const rotateX = useTransform(scrollYProgress, [0, 1], [30, -30]);
  const y = useTransform(scrollYProgress, [0, 1], [150, -150]);
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [0.7, 1.2, 0.8]);

  return (
    <section ref={ref} className="min-h-[100svh] py-16 px-6 md:py-24 md:px-32 flex flex-col md:flex-row items-center justify-between overflow-hidden relative bg-white">
       <div className="w-full md:w-1/2 z-10 text-center md:text-left mt-12 md:mt-0 order-2 md:order-1">
         <motion.h2 
           initial={{ opacity: 0, x: -50 }}
           whileInView={{ opacity: 1, x: 0 }}
           transition={{ duration: 0.8 }}
           viewport={{ once: true, margin: "-100px" }}
           className="text-4xl sm:text-5xl md:text-7xl font-serif font-bold mb-6 text-gray-800"
         >
           Purely<br className="hidden md:block"/>Natural.
         </motion.h2>
         <motion.p 
           initial={{ opacity: 0, x: -50 }}
           whileInView={{ opacity: 1, x: 0 }}
           transition={{ duration: 0.8, delay: 0.2 }}
           viewport={{ once: true, margin: "-100px" }}
           className="text-base sm:text-lg md:text-xl text-gray-500 max-w-md mx-auto md:mx-0 leading-relaxed"
         >
           Our ciders are crafted with 100% natural fruit juices, sourced directly from local orchards. No artificial flavors, just the crisp, refreshing taste of nature.
         </motion.p>
       </div>
       <div className="w-full md:w-1/2 flex justify-center items-center h-[350px] sm:h-[450px] md:h-[600px] order-1 md:order-2" style={{ perspective: '1200px' }}>
          <motion.div style={{ rotateY, rotateX, y, scale }} className="relative z-0">
             <div className="scale-[0.6] sm:scale-75 md:scale-100 origin-center transition-transform">
               <Can flavor={FLAVORS[0]} />
             </div>
          </motion.div>
       </div>
    </section>
  );
};

const Section2 = () => {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });

  const rotateX = useTransform(scrollYProgress, [0, 1], [-45, 45]);
  const rotateZ = useTransform(scrollYProgress, [0, 1], [-25, 25]);
  const x = useTransform(scrollYProgress, [0, 1], [-150, 150]);
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [0.8, 1.1, 0.8]);

  return (
    <section ref={ref} className="min-h-[100svh] py-16 px-6 md:py-24 md:px-32 flex flex-col md:flex-row items-center justify-between overflow-hidden relative bg-gray-50">
       <div className="w-full md:w-1/2 flex justify-center items-center h-[350px] sm:h-[450px] md:h-[600px] mb-8 md:mb-0" style={{ perspective: '1200px' }}>
          <motion.div style={{ rotateX, rotateZ, x, scale }} className="relative z-0">
             <div className="scale-[0.6] sm:scale-75 md:scale-100 origin-center transition-transform">
               <Can flavor={FLAVORS[1]} />
             </div>
          </motion.div>
       </div>
       <div className="w-full md:w-1/2 z-10 text-center md:text-right flex flex-col md:items-end">
         <motion.h2 
           initial={{ opacity: 0, x: 50 }}
           whileInView={{ opacity: 1, x: 0 }}
           transition={{ duration: 0.8 }}
           viewport={{ once: true, margin: "-100px" }}
           className="text-4xl sm:text-5xl md:text-7xl font-serif font-bold mb-6 text-gray-800"
         >
           Crisp &<br className="hidden md:block"/>Refreshing.
         </motion.h2>
         <motion.p 
           initial={{ opacity: 0, x: 50 }}
           whileInView={{ opacity: 1, x: 0 }}
           transition={{ duration: 0.8, delay: 0.2 }}
           viewport={{ once: true, margin: "-100px" }}
           className="text-base sm:text-lg md:text-xl text-gray-500 max-w-md mx-auto md:mx-0 leading-relaxed"
         >
           Experience the perfect balance of sweetness and tartness with our meticulously blended fruit ciders. Every sip delivers a burst of vibrant flavour that dances on the palate.
         </motion.p>
       </div>
    </section>
  );
};

const Section3 = () => {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });

  // Crazy 3D flip animation
  const rotateY = useTransform(scrollYProgress, [0, 0.5, 1], [120, 0, -120]);
  const rotateX = useTransform(scrollYProgress, [0, 0.5, 1], [10, -20, 10]);
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [0.6, 1.4, 0.6]);

  return (
    <section ref={ref} className="min-h-[100svh] py-16 px-6 md:py-24 flex flex-col items-center justify-center overflow-hidden relative bg-white">
       <motion.div 
           initial={{ opacity: 0, y: -30 }}
           whileInView={{ opacity: 1, y: 0 }}
           transition={{ duration: 0.6 }}
           viewport={{ once: true, margin: "-100px" }}
           className="text-center mb-8 md:mb-0 z-10"
       >
         <h2 className="text-4xl sm:text-5xl md:text-6xl font-serif font-bold mb-6 text-gray-800">
           Exotic Mixes
         </h2>
         <p className="text-base sm:text-lg md:text-xl text-gray-500 max-w-xl mx-auto px-4">
           Dare to be different. Our exotic blends bring together tropical fruits and unexpected notes for a truly unique cider experience.
         </p>
       </motion.div>
       
       <div className="w-full flex justify-center items-center h-[350px] sm:h-[450px] md:h-[500px]" style={{ perspective: '800px' }}>
          <motion.div style={{ rotateY, rotateX, scale }} className="relative z-0">
             <div className="scale-[0.6] sm:scale-75 md:scale-100 origin-center transition-transform">
               <Can flavor={FLAVORS[2]} />
             </div>
          </motion.div>
       </div>
    </section>
  );
};

const CatalogCard = ({ flavor, index }: { flavor: Flavor, index: number }) => {
  const { addToCart } = useAppContext();
  const ref = useRef<HTMLDivElement>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const mouseXSpring = useSpring(x, { stiffness: 300, damping: 30 });
  const mouseYSpring = useSpring(y, { stiffness: 300, damping: 30 });

  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ["25deg", "-25deg"]);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ["-25deg", "25deg"]);
  const scale = useTransform(mouseYSpring, [-0.5, 0.5], [1.05, 1.05]); // slightly scale up on overall hover

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const xPct = mouseX / width - 0.5;
    const yPct = mouseY / height - 0.5;
    x.set(xPct);
    y.set(yPct);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, delay: index * 0.2 }}
      viewport={{ once: true }}
      className="flex flex-col items-center"
      style={{ perspective: '1200px' }}
    >
      <motion.div 
        ref={ref}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        className="w-full flex justify-center items-center h-[350px] sm:h-[400px] md:h-[500px] rounded-3xl cursor-crosshair"
        style={{ 
          rotateX,
          rotateY,
          scale,
          transformStyle: "preserve-3d",
          background: `radial-gradient(circle at center, ${flavor.color}20 0%, transparent 70%)` 
        }}
      >
        <div 
          className="relative pointer-events-none drop-shadow-2xl" 
          style={{ transform: "translateZ(80px)", transition: "transform 0.1s ease-out" }}
        >
           <div className="scale-[0.6] sm:scale-75 md:scale-100 origin-center transition-transform">
             <Can flavor={flavor} />
           </div>
        </div>
      </motion.div>
      <motion.div 
        className="mt-8 text-center transform transition-transform duration-500"
      >
        <h3 className="text-2xl font-bold text-gray-900 mb-2">{flavor.subtitle}</h3>
        <div className="text-3xl font-black text-gray-800 mb-6 flex items-center justify-center">
          <span className="text-xl mr-1 text-gray-500 font-normal">₹</span>{flavor.price}
        </div>
        
        <div className="flex gap-4 justify-center">
          <a 
            href={`https://wa.me/1234567890?text=I'm interested in buying the ${flavor.subtitle} cider (₹${flavor.price})`} 
            target="_blank" 
            rel="noreferrer"
            className="flex text-sm items-center gap-2 bg-[#25D366] text-white px-5 py-3 rounded-full font-bold hover:bg-[#1fb355] hover:scale-105 transition-all shadow-lg hover:shadow-xl"
          >
            <MessageCircle size={18} />
            WhatsApp
          </a>
          <button 
            onClick={() => addToCart(flavor)}
            className="flex text-sm items-center gap-2 bg-gray-900 text-white px-5 py-3 rounded-full font-bold hover:bg-gray-800 transition-all hover:scale-105 shadow-lg cursor-pointer"
          >
            <ShoppingBag size={18} />
            Add to Cart
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
};

const CatalogSection = () => {
  return (
    <section className="py-20 px-6 md:py-32 md:px-24 bg-gray-50 relative z-10">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true, margin: "-100px" }}
          className="text-center mb-16 md:mb-24"
        >
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-black tracking-tighter mb-4 text-gray-900 uppercase">
            The Catalog
          </h2>
          <p className="text-lg md:text-xl text-gray-500 font-serif italic">Choose your perfect flavor.</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-16 md:gap-8">
          {FLAVORS.map((flavor, index) => (
            <CatalogCard key={flavor.id} flavor={flavor} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};

const BrandDetailsSection = () => {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });

  const rotateX = useTransform(scrollYProgress, [0, 1], [30, -30]);
  const rotateY = useTransform(scrollYProgress, [0, 1], [-20, 20]);
  const z = useTransform(scrollYProgress, [0, 0.5, 1], [-100, 50, -100]);

  return (
    <section ref={ref} className="py-20 px-6 md:py-32 md:px-24 bg-white relative z-10 border-t border-gray-100 overflow-hidden">
      <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-center gap-12 md:gap-16" style={{ perspective: '1500px' }}>
        <div className="w-full md:w-1/2 flex justify-center items-center order-2 md:order-1">
           <motion.div 
              style={{ rotateX, rotateY, z, transformStyle: "preserve-3d" }}
              className="relative w-full max-w-[280px] md:max-w-sm aspect-square rounded-[3rem] overflow-hidden drop-shadow-2xl"
           >
              {/* Animated gradient background map */}
              <motion.div 
                animate={{ backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"] }}
                transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
                className="absolute inset-0"
                style={{ 
                  background: 'linear-gradient(-45deg, #f5f7fa, #c3cfe2, #fad0c4, #ffd1ff)',
                  backgroundSize: '400% 400%' 
                }}
              />
              
              <div className="absolute inset-0 flex items-center justify-center transform-gpu" style={{ transform: "translateZ(80px)" }}>
                 <div className="w-1/2 h-1/2 bg-white/40 rounded-full mix-blend-overlay blur-3xl" />
                 <h2 className="absolute text-5xl md:text-7xl font-serif italic text-black/10 font-black tracking-tighter mix-blend-color-burn transform -rotate-12 select-none">
                   EST. 2024
                 </h2>
                 <motion.div 
                   animate={{ y: [0, -15, 0], rotateZ: [0, 2, -2, 0] }}
                   transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                   className="relative text-center z-10 w-[85%] h-[85%] rounded-full border border-white/60 flex flex-col items-center justify-center bg-white/20 backdrop-blur-md shadow-lg"
                   style={{ transformStyle: "preserve-3d" }}
                 >
                    <span className="text-4xl md:text-5xl font-black tracking-tighter text-gray-800 drop-shadow-sm pointer-events-none" style={{ transform: "translateZ(40px)" }}>Fruity.</span>
                    <span className="text-[10px] md:text-xs font-bold tracking-[0.4em] uppercase text-gray-700 mt-2 block pointer-events-none" style={{ transform: "translateZ(20px)" }}>Brewed Natural</span>
                 </motion.div>
              </div>
           </motion.div>
        </div>
        <div className="w-full md:w-1/2 text-center md:text-left order-1 md:order-2">
           <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
           >
              <h4 className="text-base md:text-lg font-bold uppercase tracking-widest text-gray-400 mb-4">Our Story</h4>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-bold text-gray-900 mb-8 leading-tight">
                Authentic blends from pristine orchards.
              </h2>
              <div className="space-y-6 text-lg md:text-xl text-gray-500 leading-relaxed font-light">
                <p>
                  We started Fruity in 2024 with a simple idea: cider should taste like real fruit. 
                  No artificial sweeteners, no chemical extracts. Just the bold, vibrant flavor of nature, captured in a can.
                </p>
                <p>
                  Each batch is independently brewed in small quantities, utilizing cold-press techniques to preserve the original essence and crisp finish. 
                  Whether you're reaching for the classic Apple, crisp Pear, or daring Exotic mix—you're opening a masterpiece.
                </p>
              </div>
           </motion.div>
        </div>
      </div>
    </section>
  );
};

export const ScrollSections = () => {
  return (
    <div className="w-full relative z-20 shadow-[0_-20px_50px_rgba(0,0,0,0.5)]">
      <Section1 />
      <Section2 />
      <Section3 />
      <CatalogSection />
      <BrandDetailsSection />
      
      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16 px-6 md:py-24 md:px-24 text-center md:text-left">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-16">
           <div>
             <h3 className="text-3xl font-black mb-6 tracking-tighter">Fruity.</h3>
             <p className="text-gray-400 leading-relaxed max-w-sm mx-auto md:mx-0">
               Crafting the world's most vibrant and natural fruit ciders since 2024. Drink responsibly and enjoy the freshness.
             </p>
           </div>
           <div>
              <h4 className="font-bold text-lg mb-6 uppercase tracking-widest text-gray-300">Explore</h4>
              <ul className="space-y-4 text-gray-400 font-medium">
                <li><a href="#" className="hover:text-white transition">Our Flavors</a></li>
                <li><a href="#" className="hover:text-white transition">About Us</a></li>
                <li><a href="#" className="hover:text-white transition">Process</a></li>
                <li><a href="#" className="hover:text-white transition">Find a Store</a></li>
              </ul>
           </div>
           <div>
              <h4 className="font-bold text-lg mb-6 uppercase tracking-widest text-gray-300">Stay Updated</h4>
              <p className="text-gray-400 mb-6 max-w-sm mx-auto md:mx-0">Subscribe to our newsletter for exclusive offers and new flavor drops.</p>
              <form className="flex flex-col sm:flex-row gap-3 sm:gap-0 max-w-sm mx-auto md:mx-0" onSubmit={e => e.preventDefault()}>
                <input type="email" placeholder="Your email address" className="bg-gray-800 text-white px-5 py-4 w-full outline-none focus:ring-2 focus:ring-white/50 rounded-xl sm:rounded-r-none sm:rounded-l-xl transition" />
                <button className="bg-white text-gray-900 px-6 py-4 font-bold hover:bg-gray-200 transition rounded-xl sm:rounded-l-none sm:rounded-r-xl whitespace-nowrap cursor-pointer">SUBSCRIBE</button>
              </form>
           </div>
        </div>
        <div className="max-w-6xl mx-auto mt-16 pt-8 border-t border-gray-800 text-center text-gray-500 text-sm">
           &copy; {new Date().getFullYear()} Fruity Cider Company. All rights reserved.
        </div>
      </footer>
    </div>
  );
};
