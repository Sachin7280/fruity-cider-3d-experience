import React from 'react';

export const AppleSVG = () => (
  <svg viewBox="0 0 100 100" width="1em" height="1em" className="drop-shadow-lg">
     <path d="M50 15 C70 0, 95 20, 90 45 C80 85, 60 95, 50 90 C40 95, 20 85, 10 45 C5 20, 30 0, 50 15 Z" fill="#E63946" />
     <path d="M50 18 C65 6, 85 22, 82 45 C74 78, 58 88, 50 85 C42 88, 26 78, 18 45 C15 22, 35 6, 50 18 Z" fill="#F1FAEE" />
     <path d="M45 45 Q50 60 55 45" fill="none" stroke="#e0e0e0" strokeWidth="2" />
     <ellipse cx="45" cy="50" rx="2" ry="4" fill="#4A4E69" transform="rotate(-15 45 50)" />
     <ellipse cx="55" cy="50" rx="2" ry="4" fill="#4A4E69" transform="rotate(15 55 50)" />
     <path d="M50 15 Q45 5 55 5" fill="none" stroke="#606C38" strokeWidth="3" strokeLinecap="round" />
     <path d="M55 5 C60 0, 70 5, 65 15 C60 10, 50 10, 55 5 Z" fill="#A7C957" />
  </svg>
);

export const PearSVG = () => (
  <svg viewBox="0 0 100 100" width="1em" height="1em" className="drop-shadow-lg">
     <path d="M50 10 C65 10, 70 35, 85 65 C95 85, 75 95, 50 95 C25 95, 5 85, 15 65 C30 35, 35 10, 50 10 Z" fill="#A7C957" />
     <path d="M50 14 C61 14, 65 37, 78 65 C85 80, 70 90, 50 90 C30 90, 15 80, 22 65 C35 37, 39 14, 50 14 Z" fill="#F1FAEE" />
     <circle cx="50" cy="65" r="12" fill="#E9ECEF" />
     <ellipse cx="46" cy="65" rx="2" ry="4" fill="#4A4E69" transform="rotate(-15 46 65)" />
     <ellipse cx="54" cy="65" rx="2" ry="4" fill="#4A4E69" transform="rotate(15 54 65)" />
     <path d="M50 10 Q50 0 55 2" fill="none" stroke="#606C38" strokeWidth="3" strokeLinecap="round" />
     <path d="M55 2 C65 -5, 75 5, 65 15 C60 5, 50 5, 55 2 Z" fill="#606C38" />
  </svg>
);

export const PassionFruitSVG = ({ fill = "#4B0082", inner = "#FFA500" }: { fill?: string, inner?: string }) => (
   <svg viewBox="0 0 100 100" width="1em" height="1em" className="drop-shadow-lg">
     <circle cx="50" cy="50" r="48" fill={fill} />
     <circle cx="50" cy="50" r="42" fill="#f4f4f4" />
     <circle cx="50" cy="50" r="35" fill={inner} />
     <circle cx="45" cy="40" r="2" fill="#2d004b" />
     <circle cx="55" cy="50" r="2.5" fill="#2d004b" />
     <circle cx="48" cy="60" r="1.5" fill="#2d004b" />
     <circle cx="60" cy="42" r="2" fill="#2d004b" />
     <circle cx="38" cy="52" r="2" fill="#2d004b" />
     <circle cx="52" cy="70" r="1.5" fill="#2d004b" stroke="#000" opacity="0.5"/>
     <circle cx="32" cy="40" r="2" fill="#2d004b" />
     <circle cx="50" cy="30" r="2" fill="#2d004b" />
     <circle cx="65" cy="58" r="2" fill="#2d004b" />
   </svg>
);
