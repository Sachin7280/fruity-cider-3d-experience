import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Plus, Minus, Trash2 } from 'lucide-react';
import { useAppContext } from '../context/AppContext';

export const CartDrawer = () => {
  const { cart, isCartOpen, setIsCartOpen, updateQuantity, removeFromCart } = useAppContext();

  const total = cart.reduce((sum, item) => sum + item.flavor.price * item.quantity, 0);

  return (
    <AnimatePresence>
      {isCartOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsCartOpen(false)}
            className="fixed inset-0 bg-black/50 z-[100] backdrop-blur-sm"
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed top-0 right-0 bottom-0 w-full max-w-md bg-white z-[101] shadow-2xl flex flex-col"
          >
            <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/80 backdrop-blur-md">
              <h2 className="text-2xl font-black text-gray-900 tracking-tighter">Your Cart</h2>
              <button 
                onClick={() => setIsCartOpen(false)}
                className="p-2 hover:bg-gray-200 rounded-full transition-colors cursor-pointer"
               >
                <X size={24} className="text-gray-600" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-white">
              {cart.length === 0 ? (
                <div className="text-center text-gray-500 mt-20">
                   <p className="text-xl font-medium mb-4">Your cart is empty.</p>
                   <button onClick={() => setIsCartOpen(false)} className="text-gray-900 font-bold hover:underline cursor-pointer">Continue shopping</button>
                </div>
              ) : (
                cart.map(item => (
                  <div key={item.flavor.id} className="flex gap-4 items-center bg-gray-50 p-4 rounded-2xl">
                     <div 
                       className="w-16 h-16 rounded-xl flex items-center justify-center shrink-0 border border-gray-200 shadow-sm"
                       style={{ background: item.flavor.canGradient }}
                      >
                         <div className="text-3xl drop-shadow-md">{item.flavor.icon}</div>
                     </div>
                     <div className="flex-1">
                        <h4 className="font-bold text-gray-900">{item.flavor.subtitle}</h4>
                        <div className="font-medium text-gray-500 text-sm">₹{item.flavor.price}</div>
                        <div className="flex items-center gap-3 mt-2">
                           <button onClick={() => updateQuantity(item.flavor.id, item.quantity - 1)} className="p-1.5 bg-white border border-gray-200 rounded-lg hover:bg-gray-100 text-gray-600 shadow-sm transition-colors cursor-pointer"><Minus size={14} /></button>
                           <span className="font-bold text-gray-800 w-4 text-center">{item.quantity}</span>
                           <button onClick={() => updateQuantity(item.flavor.id, item.quantity + 1)} className="p-1.5 bg-white border border-gray-200 rounded-lg hover:bg-gray-100 text-gray-600 shadow-sm transition-colors cursor-pointer"><Plus size={14} /></button>
                        </div>
                     </div>
                     <div className="text-right flex flex-col items-end gap-2">
                        <div className="font-black text-lg text-gray-800">
                           ₹{item.flavor.price * item.quantity}
                        </div>
                        <button onClick={() => removeFromCart(item.flavor.id)} className="text-red-500 hover:text-red-700 p-2 hover:bg-red-50 rounded-full transition-colors cursor-pointer">
                           <Trash2 size={18} />
                        </button>
                     </div>
                  </div>
                ))
              )}
            </div>

            {cart.length > 0 && (
              <div className="p-6 border-t border-gray-100 bg-gray-50">
                <div className="flex justify-between items-center mb-6">
                  <span className="text-lg font-medium text-gray-600">Total:</span>
                  <span className="text-3xl font-black text-gray-900">₹{total}</span>
                </div>
                <button className="w-full bg-gray-900 text-white font-bold text-lg py-4 rounded-full hover:bg-gray-800 hover:scale-[1.02] transition-all shadow-xl cursor-pointer">
                  Checkout Now
                </button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
