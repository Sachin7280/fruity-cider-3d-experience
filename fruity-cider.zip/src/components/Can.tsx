import React from 'react';
import { Flavor } from '../types';

interface CanProps {
  flavor: Flavor;
}

export const Can: React.FC<CanProps> = ({ flavor }) => {
  return (
    <div className="relative w-64 h-[32rem] rounded-[30px] shadow-[0_40px_80px_rgba(0,0,0,0.4)] flex flex-col items-center select-none">
      {/* Background Gradient & Cylinder shading */}
      <div 
        className="absolute inset-0 rounded-[30px] overflow-hidden" 
        style={{ background: flavor.canGradient }}
      >
         {/* Metallic highlights */}
         <div className="absolute top-0 bottom-0 left-[12%] w-[10%] bg-white/40 blur-md pointer-events-none" />
         <div className="absolute top-0 bottom-0 right-[8%] w-[15%] bg-black/20 blur-[20px] pointer-events-none" />
         
         {/* Condensation (Subtle noise/dots) */}
         <div 
            className="absolute inset-0 opacity-30 mix-blend-overlay" 
            style={{
                backgroundImage: "radial-gradient(circle at 50% 50%, #ffffff 1px, transparent 1.5px)", 
                backgroundSize: "12px 18px"
            }} 
         />

         {/* Label Area */}
         <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 flex items-center justify-center pointer-events-none">
            <div className="w-48 h-64 bg-[#fdfdfd] rounded-[40px] flex flex-col items-center justify-center p-4 text-center border border-white/50 relative shadow-inner overflow-hidden">
               {/* Decorative border */}
               <div className="absolute inset-2 border-[1.5px] border-dashed border-gray-300 rounded-[32px] pointer-events-none" />
               
               <h3 className="font-bold text-gray-800 tracking-[0.15em] mb-1 text-[11px] z-10 mt-2 whitespace-nowrap uppercase">
                  FRUIT CIDER
               </h3>
               <p className="font-serif italic text-gray-500 text-[9px] z-10">Extra delicious</p>
               
               <div className="text-[5rem] my-3 drop-shadow-md z-10 leading-none">
                  {flavor.icon}
               </div>
               
               <h2 
                  className="text-[1.8rem] font-bold text-gray-900 z-10 leading-none" 
                  style={{ fontFamily: "'Playfair Display', serif" }}
               >
                  {flavor.subtitle}
               </h2>
               
               <p className="text-[6px] font-bold tracking-widest uppercase text-gray-400 mt-4 z-10">
                  100% With Natural Fruit
               </p>
               <p className="text-[6px] font-bold tracking-widest uppercase text-gray-400 mt-1 z-10">
                  330 ML — 4.5% ALC
               </p>
            </div>
         </div>
      </div>

      {/* Top Rim */}
      <div className="absolute top-0 w-full h-[18px] bg-gradient-to-b from-gray-100 via-gray-300 to-gray-400 rounded-t-[30px] border-b border-gray-500/50 shadow-sm" />
      
      {/* Bottom Rim */}
      <div className="absolute bottom-0 w-[94%] h-[24px] bg-gradient-to-r from-gray-500 via-gray-300 to-gray-600 rounded-b-[40px] shadow-[inset_0_-4px_10px_rgba(0,0,0,0.2)] border-t border-gray-500/50" />
    </div>
  );
};
