import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence, useScroll, useTransform } from 'motion/react';
import { ShoppingBag, ArrowLeft, ArrowRight, Menu, X } from 'lucide-react';
import { FLAVORS, FLOATING_ITEMS } from './data';
import { Can } from './components/Can';
import { FloatingFruit } from './components/FloatingFruit';
import { ScrollSections } from './components/ScrollSections';
import { useAppContext } from './context/AppContext';
import { CartDrawer } from './components/CartDrawer';
import { RegisterModal } from './components/RegisterModal';

export default function App() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(1);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { cart, setIsCartOpen, setIsRegisterOpen, user } = useAppContext();

  const { scrollY } = useScroll();
  const heroCanRotateY = useTransform(scrollY, [0, 800], [0, 360]);
  const heroBgHueRotate = useTransform(scrollY, [0, 800], ["hue-rotate(0deg)", "hue-rotate(90deg)"]);

  const paginate = (newDirection: number) => {
    let nextIndex = currentIndex + newDirection;
    if (nextIndex >= FLAVORS.length) nextIndex = 0;
    if (nextIndex < 0) nextIndex = FLAVORS.length - 1;
    setDirection(newDirection);
    setCurrentIndex(nextIndex);
  };

  useEffect(() => {
    const timer = setInterval(() => {
      setDirection(1);
      setCurrentIndex(prev => (prev + 1) % FLAVORS.length);
    }, 2500);
    return () => clearInterval(timer);
  }, []);

  const flavor = FLAVORS[currentIndex];

  return (
    <div className="relative w-full overflow-x-hidden font-sans selection:bg-white/30 bg-black">
      
      {/* Hero Section (Sticky) */}
      <div className="sticky top-0 w-full h-[100svh] overflow-hidden" style={{ perspective: '2000px', backgroundColor: flavor.color, transition: "background-color 1s ease" }}>
        {/* Background Wiping Slides */}
        <AnimatePresence initial={false} custom={direction}>
          <motion.div
            key={currentIndex}
            custom={direction}
            initial={{ 
              opacity: 0,
              rotateY: direction > 0 ? -45 : 45,
              z: -500,
              x: direction > 0 ? '50%' : '-50%',
              zIndex: 10 
            }}
            animate={{ 
              opacity: 1,
              rotateY: 0,
              z: 0,
              x: '0%',
              zIndex: 10 
            }}
            exit={{ 
              opacity: 0,
              rotateY: direction > 0 ? 45 : -45,
              z: -500,
              x: direction > 0 ? '-50%' : '50%',
              zIndex: 0 
            }}
            transition={{ duration: 1, ease: [0.34, 1.56, 0.64, 1] }}
            className="absolute inset-0 flex items-center justify-center overflow-hidden"
            style={{ backgroundColor: flavor.color, filter: heroBgHueRotate, transformStyle: "preserve-3d" }}
          >
            {/* HUGE Background Text */}
            <motion.h1
              initial={{ x: direction > 0 ? 200 : -200, rotateY: direction > 0 ? 30 : -30, z: -200, opacity: 0 }}
              animate={{ x: 0, rotateY: 0, z: 0, opacity: 1 }}
              exit={{ x: direction > 0 ? -200 : 200, rotateY: direction > 0 ? -30 : 30, z: -200, opacity: 0 }}
              transition={{ duration: 1, ease: [0.34, 1.56, 0.64, 1], delay: 0.2 }}
              className="absolute text-[40vw] md:text-[32vw] font-black tracking-tighter text-white/90 select-none whitespace-nowrap z-0 pointer-events-none"
              style={{ textShadow: "0 20px 40px rgba(0,0,0,0.05)", transformStyle: "preserve-3d" }}
            >
              {flavor.title}
            </motion.h1>

            {/* Central Can */}
            <motion.div
              initial={{ scale: 0.5, z: 400, rotateX: direction > 0 ? -30 : 30, opacity: 0 }}
              animate={{ scale: 1, z: 0, rotateX: 0, opacity: 1 }}
              exit={{ scale: 0.5, z: 400, rotateX: direction > 0 ? 30 : -30, opacity: 0 }}
              transition={{ duration: 1, ease: [0.34, 1.56, 0.64, 1], delay: 0.1 }}
              className="z-10 relative pointer-events-none"
              style={{ transformStyle: "preserve-3d" }}
            >
              <motion.div 
                 className="scale-[0.65] sm:scale-75 md:scale-100 origin-center transition-transform duration-500"
                 style={{ rotateY: heroCanRotateY, transformStyle: "preserve-3d" }}
              >
                <Can flavor={flavor} />
              </motion.div>
            </motion.div>

            {/* Floating Fruits */}
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }} 
              transition={{ duration: 0.5 }}
              className="absolute inset-0 pointer-events-none"
              style={{ transformStyle: "preserve-3d" }}
            >
              {FLOATING_ITEMS[flavor.id].map((item) => (
                <FloatingFruit key={item.id} item={item} direction={direction} />
              ))}
            </motion.div>

          </motion.div>
        </AnimatePresence>

        {/* Global Foreground UI */}
        <header className="absolute top-0 left-0 right-0 py-6 px-6 md:py-10 md:px-24 flex justify-between items-center z-50 text-white pointer-events-auto">
          <div className="text-2xl md:text-3xl font-black tracking-tighter drop-shadow-md">Fruity</div>
          
          {/* Desktop Nav */}
          <nav className="hidden md:flex space-x-16 font-semibold text-lg tracking-wide drop-shadow-md">
            {FLAVORS.map((f, i) => (
              <button 
                key={f.id} 
                onClick={() => {
                  if(currentIndex === i) return;
                  setDirection(i > currentIndex ? 1 : -1);
                  setCurrentIndex(i);
                }}
                className={`hover:opacity-100 transition-all ${currentIndex === i ? 'opacity-100 drop-shadow-xl scale-110' : 'opacity-60'}`}
              >
                {f.title}
              </button>
            ))}
          </nav>

          {/* Desktop Actions */}
          <div className="hidden md:flex space-x-6 font-semibold tracking-wide items-center drop-shadow-md">
            <button onClick={() => setIsCartOpen(true)} className="hover:opacity-80 transition-opacity flex items-center gap-2 relative cursor-pointer">
              <ShoppingBag size={20} />
              Cart
              {cart.length > 0 && (
                <span className="absolute -top-2 -right-3 bg-red-500 text-white text-[10px] w-5 h-5 flex items-center justify-center rounded-full font-bold animate-pulse shadow-md">
                  {cart.length}
                </span>
              )}
            </button>
            <span className="opacity-40">|</span>
            <button onClick={() => setIsRegisterOpen(true)} className="hover:opacity-80 transition-opacity flex items-center gap-2 cursor-pointer">
              {user ? (
                <span className="truncate max-w-[100px]">{user.name}</span>
              ) : (
                "Register"
              )}
            </button>
          </div>

          {/* Mobile Actions */}
          <div className="flex md:hidden items-center gap-6 drop-shadow-md">
            <button onClick={() => setIsCartOpen(true)} className="relative cursor-pointer hover:opacity-80 transition-opacity">
              <ShoppingBag size={24} />
              {cart.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-[10px] w-5 h-5 flex items-center justify-center rounded-full font-bold animate-pulse shadow-md">
                  {cart.length}
                </span>
              )}
            </button>
            <button onClick={() => setIsMobileMenuOpen(true)} className="cursor-pointer hover:opacity-80 transition-opacity">
              <Menu size={28} />
            </button>
          </div>
        </header>

        {/* Global Bottom Navigation */}
        <div className="absolute bottom-6 md:bottom-12 left-0 right-0 px-6 md:px-24 flex justify-between items-center z-50 text-white pointer-events-auto drop-shadow-md">
          <button 
            onClick={() => paginate(-1)} 
            className="w-12 h-12 md:w-14 md:h-14 flex items-center justify-center hover:bg-white/10 rounded-full transition cursor-pointer"
          >
            <ArrowLeft size={32} strokeWidth={2.5} />
          </button>
          <button className="font-extrabold tracking-[0.2em] text-sm md:text-lg hover:scale-105 transition-transform cursor-pointer">
            SHOP NOW
          </button>
          <button 
            onClick={() => paginate(1)} 
            className="w-12 h-12 md:w-14 md:h-14 flex items-center justify-center hover:bg-white/10 rounded-full transition cursor-pointer"
          >
            <ArrowRight size={32} strokeWidth={2.5} />
          </button>
        </div>
      </div>
      
      {/* Scrollable Sections Overlay */}
      <ScrollSections />

      <CartDrawer />
      <RegisterModal />

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 bg-gray-900/95 backdrop-blur-md z-[100] text-white flex flex-col p-6 pointer-events-auto"
          >
            <div className="flex justify-between items-center mb-12">
              <div className="text-2xl font-black tracking-tighter">Fruity</div>
              <button onClick={() => setIsMobileMenuOpen(false)} className="p-2 cursor-pointer hover:bg-white/10 rounded-full transition">
                <X size={28} />
              </button>
            </div>
            <nav className="flex flex-col gap-6 text-3xl font-black tracking-tighter">
              {FLAVORS.map((f, i) => (
                <button 
                  key={f.id} 
                  onClick={() => {
                    if(currentIndex !== i) {
                      setDirection(i > currentIndex ? 1 : -1);
                      setCurrentIndex(i);
                    }
                    setIsMobileMenuOpen(false);
                  }}
                  className={`text-left w-full transition-colors ${currentIndex === i ? 'text-white' : 'text-gray-500'}`}
                >
                  {f.title}
                </button>
              ))}
            </nav>
            <div className="mt-auto pt-8 border-t border-gray-800 space-y-4">
               <button 
                  onClick={() => { setIsMobileMenuOpen(false); setIsRegisterOpen(true); }}
                  className="w-full bg-white text-gray-900 font-bold py-4 rounded-full text-lg cursor-pointer hover:bg-gray-200 transition"
               >
                  {user ? `Account (${user.name})` : 'Register / Login'}
               </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
