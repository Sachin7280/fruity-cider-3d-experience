import { ReactNode } from "react";

export interface Flavor {
  id: string;
  title: string;
  color: string;
  canGradient: string;
  subtitle: string;
  icon: ReactNode | string;
  price: number;
}

export interface FloatingItem {
  id: number;
  content: ReactNode | string;
  x: string;
  y: string;
  size: string;
  rotate: number;
  delay: number;
}
